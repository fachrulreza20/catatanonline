
Data Statistik