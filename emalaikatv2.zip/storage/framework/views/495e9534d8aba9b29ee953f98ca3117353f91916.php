         <!-- Home page -->
         <div id="page-home" class="active">
            <h3>Home Page</h3>

            <h4>
              Tabel dosa beserta jumlah usernya <br>
              Tabel pahala beserta jumlah usernya
            </h4>
            <br>
            <div align="center">

                  <?php if(auth()->guard()->check()): ?>
                        You Logged as 
                        <a class="badge badge-primary text-white"  id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                           <?php echo e(strtoupper(Auth::user()->name)); ?> <span class="caret"></span>
                        </a>
                        &nbsp;
                        
                            <a class="badge badge-danger" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                            </form>
                        

                    <?php else: ?>
                        <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Login</a>
                        
                        &nbsp; or &nbsp; 

                        <?php if(Route::has('register')): ?>
                            <a class="btn btn-success" href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                  <?php endif; ?>
            </div>

          </div><?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/tab_home.blade.php ENDPATH**/ ?>