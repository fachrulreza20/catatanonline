

<!-- Dosa page -->
         <div id="page-dosa" class="active">
           <br>

            <h5 class="text-center">Dsa User</h5>




            <div class="card-body grey lighten-5" id="rowitems_dosa">
              <div class="row">
              <?php $i=1; ?>
              <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($item->categories->title == "Dosa" ): ?>
                  
               
                  <?php if($i<=3): ?>
                        

                          <div class="col-4 p-1">
                            <div class="card grey lighten-2  text-center">
                              <div class="card-body pb-0">
                                <i class="fas fa-cloud fa-3x pb-4"></i>
                                <div class="text-center mb-2">
                                  <p class="mb-0 h4 text-center"> <?php echo e($item->title); ?>  </p>                                  

                                </div>
                              </div>
                              <div class="card-body pt-0">
                                  
                                <p class="mb-0 h3 text-danger" id="nilaiItem<?php echo e($item->id); ?>"> <?php echo e($item->nilai); ?></p>
                              </div>
                              
                              <button class="btn btn-block btn-danger btn-sm" onclick="addButton(<?php echo e($item->id); ?>)">+</button>   
                            </div>       
                          </div> <!-- Grid column -->
                  <?php else: ?>
                    </div> <!-- Grid row -->
                      <div class="row">
                        <?php $i = 1;  ?>

                        <div class="col-4 p-1">
                          <div class="card grey lighten-2  text-center">
                            <div class="card-body pb-0">
                              <i class="fas fa-cloud fa-3x pb-4"></i>
                              <div class="text-center mb-2">
                                <p class="mb-0 h4 text-center"> <?php echo e($item->title); ?>  </p>                                  

                              </div>
                            </div>
                            <div class="card-body pt-0">
                                
                              <p class="mb-0 h3 text-danger" id="nilaiItem<?php echo e($item->id); ?>"> <?php echo e($item->nilai); ?></p>
                            </div>
                            
                            <button class="btn btn-block btn-danger btn-sm" onclick="addButton(<?php echo e($item->id); ?>)">+</button>   
                          </div>       
                        </div> <!-- Grid column -->


                  <?php endif; ?>
               
              
                  <?php $i++;  ?>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              
               </div> <!-- Grid row --> 
         </div>





         </div> <!-- close page-dosa -->
         <?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/user/tab_dosa.blade.php ENDPATH**/ ?>