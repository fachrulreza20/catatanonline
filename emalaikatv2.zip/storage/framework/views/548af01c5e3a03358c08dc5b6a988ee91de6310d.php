         <!-- Dosa page -->
         <div id="page-dosa" class="inactive">
            <h3>Dosa user</h3>

          </div><?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/tab_dosa.blade.php ENDPATH**/ ?>