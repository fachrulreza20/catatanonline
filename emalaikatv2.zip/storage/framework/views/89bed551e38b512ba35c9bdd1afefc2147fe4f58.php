

<!-- Bottom Nav Bar -->

     <?php if(auth()->guard()->check()): ?>    

     <footer class="footer">
        <div id="buttonGroup" class="btn-group selectors" role="group" aria-label="Basic example">
           <button id="home" type="button" class="btn btn-secondary button-active">
              <div class="selector-holder">
                 <i class="material-icons">home</i>
                 <span>Home</span>
              </div>
           </button>
           <button id="dosa" type="button" class="btn btn-secondary button-inactive">
              <div class="selector-holder">
                 <i class="material-icons">view_list</i>
                 <span>Dosa</span>
              </div>
           </button>
           <button id="pahala" type="button" class="btn btn-secondary button-inactive">
              <div class="selector-holder">
                 <i class="material-icons">create</i>
                 <span>Pahala</span>
              </div>
           </button>
           <button id="account" type="button" class="btn btn-secondary button-inactive">
              <div class="selector-holder">
                 <i class="material-icons">account_circle</i>
                 <span>Account</span>
              </div>
           </button>
        </div>
     </footer>

     <?php else: ?>
     <br><br><br>
     <div style="margin: 0" class="" align="center">
       <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Login</a>
       &nbsp; or  &nbsp;
       <?php if(Route::has('register')): ?>
           <a class="btn btn-success" href="<?php echo e(route('register')); ?>">Register</a>
       <?php endif; ?>
   </div>
     <?php endif; ?>

<?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/bottomnav.blade.php ENDPATH**/ ?>