         <!-- Create page -->
         <div id="page-pahala" class="inactive">
            <h1>Pahala user</h1>

          </div><?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/tab_pahala.blade.php ENDPATH**/ ?>