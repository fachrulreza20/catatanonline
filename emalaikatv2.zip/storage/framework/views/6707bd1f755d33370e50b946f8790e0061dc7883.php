         <!-- account page -->
         <div id="page-account" class="inactive">
            <h2>Account Page</h2>
            <div class="block">
              <h2>The standard Lorem Ipsum passage</h2>
  
              "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
              Section 1.10.32 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC
            </div>
         </div><?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/user/tab_account.blade.php ENDPATH**/ ?>