         <!-- Home page -->
         <div id="page-home" class="active">

            <br>
            <div align="center">

                <?php echo $__env->make('front/frontStatistik', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <br>
                <br>
                <br>
                  <?php if(auth()->guard()->check()): ?>

                        

                    <?php else: ?>
                        <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Login</a>
                        
                        &nbsp; or &nbsp; 

                        <?php if(Route::has('register')): ?>
                            <a class="btn btn-success" href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                  <?php endif; ?>
            </div>

          </div><?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/frontcontent.blade.php ENDPATH**/ ?>