         <!-- Home page -->
         <div id="page-home" class="active">
            <h3>Home Page</h3>

            <h4>
              Tabel dosa beserta jumlah usernya <br>
              Tabel pahala beserta jumlah usernya
            </h4>
          </div><?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/user/tab_home.blade.php ENDPATH**/ ?>