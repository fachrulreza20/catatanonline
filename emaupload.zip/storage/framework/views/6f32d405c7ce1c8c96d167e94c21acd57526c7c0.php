

<!-- Bottom Nav Bar -->

<a href="/user/">

     <footer class="footer" style="text-align: center;">
           <button id="dosa" type="button" class="btn btn-light button-active">
              <div class="selector-holder">
                    <i class="material-icons">add_circle</i>
                    <span>Input Data</span>
              </div>
           </button>
     </footer>
   </a>

     

<?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/frontbottom.blade.php ENDPATH**/ ?>