         <!-- account page -->
         <div id="page-account" class="inactive" style="margin-top:-50px; background-color:#fff;position:absolute;z-index:1000; width:100%;">
            <h4>Your Profile </h4>
            <div class="block">
              <br>
              <h5>Dosa</h5>
              <table class="table table-hover table-condensed table-striped table-bordered">
                <tr class="bg-danger text-light">
                  <th>Item</th>
                  <th>Score</th>
                  <th>Last Update</th>
                </tr>

                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                  <?php if($item->categories_id == "1"): ?>
                    <tr>
                      <td style="padding:2px"><?php echo e($item->title); ?></td>
                      <td style="padding:2px"><?php echo e($item->nilai); ?></td>
                      <td style="padding:2px"><?php echo e($item->updated_at->diffForHumans()); ?></td>
                    </tr>
                  <?php endif; ?>                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
              </table>

             

              <br>
              <h5>Pahala</h5>
              <table class="table table-hover table-condensed table-striped table-bordered">
                <tr class="bg-success text-light">
                  <th>Item</th>
                  <th>Score</th>
                  <th>Last Update</th>
                </tr>

                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                  <?php if($item->categories_id == "2"): ?>
                    <tr>
                      <td style="padding:2px"><?php echo e($item->title); ?></td>
                      <td style="padding:2px"><?php echo e($item->nilai); ?></td>
                      <td style="padding:2px"><?php echo e($item->updated_at->diffForHumans()); ?></td>
                    </tr>
                  <?php endif; ?>                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
              </table>

            
              Support us with Follow Our IG
              <a href="https://instagram.com/catat.anonline">@catat.anonline</a>
              
            

            </div>
         </div><?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/user/tab_account.blade.php ENDPATH**/ ?>