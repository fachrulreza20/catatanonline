
<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('front/css/AdminLTE.min.css')); ?>" rel="stylesheet">


<?php $__env->stopPush(); ?>

<?php

$totalDsa = 0;
$totalPhl = 0;


?>

<?php $__currentLoopData = $collectionDsa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $totalDsa = $totalDsa + $item->counttitle;  ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $collectionPhl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $totalPhl = $totalPhl + $item->counttitle;  ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<div class="container">
<div class="row">
                <!-- /.col -->
                <div class="col-6">
                    <h5 style="text-danger">Top Dosa</h5>
                    <?php $__currentLoopData = $collectionDsa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <div class="progress-group">
                            <span class="text-right"><?php echo e($item->title); ?> (<?php echo e($item->counttitle); ?>) | </span>
                            <span class="progress-number"><b><?php echo e(number_format(($item->counttitle/$totalDsa)*100,1)); ?>%</b></span>
        
                            <div class="progress sm">
                                <div class="progress-bar bg-danger" style="width: <?php echo e(($item->counttitle/$totalDsa)*100); ?>%"></div>
                            </div>
                        </div>
                        <!-- /.progress-group -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>
                  <!-- /.col -->
                <!-- /.col -->
                <div class="col-6">
                    <h5 style="text-success">Top Phl</h5>
                    <?php $__currentLoopData = $collectionPhl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <div class="progress-group">
                            <span class="text-right"><?php echo e($item->title); ?> (<?php echo e($item->counttitle); ?>) | </span>
                            <span class="progress-number"><b><?php echo e(number_format(($item->counttitle/$totalPhl)*100,1)); ?>%</b></span>
        
                            <div class="progress sm">
                                <div class="progress-bar progress-bar-aqua" style="width: <?php echo e(($item->counttitle/$totalPhl)*100); ?>%"></div>
                            </div>
                        </div>
                        <!-- /.progress-group -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </div>
                  <!-- /.col -->

</div>
<br>
<br>
<br>
<div class="row ">
    <!-- /.col -->
    <div class="col-6">
        <h4 style="text-align: left;">Top User Dsa terbanyak</h4>
        <?php $__currentLoopData = $topUserDsa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p style="text-align: left;"><?php echo e(strtoupper($item->users->name)); ?> <span class="badge badge-danger"> <?php echo e($item->totalnilai); ?> </span> </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
    <div class="col-6">
        <h4 style="text-align: left;">Top User Phl terbanyak</h4>
        <?php $__currentLoopData = $topUserPhl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p style="text-align: left;"><?php echo e(strtoupper($item->users->name)); ?> <span class="badge badge-success"> <?php echo e($item->totalnilai); ?> </span> </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\emalaikat\resources\views/front/frontStatistik.blade.php ENDPATH**/ ?>