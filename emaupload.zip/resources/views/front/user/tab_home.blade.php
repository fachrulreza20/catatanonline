         <!-- Home page -->
         <div id="page-home" class="active">
            <h3>Home Page</h3>

            <h4>
              Tabel Dosa beserta jumlah usernya <br>
              Tabel Pahala beserta jumlah usernya
            </h4>
          </div>